import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Users, Activity, BarChart3 } from "lucide-react";
import * as XLSX from "xlsx";
import { PlayerBatting, PlayerBowling } from "@/types/player";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

export const PlayerComparison = () => {
  const [format, setFormat] = useState<"T20I" | "ODI" | "Overall">("Overall");
  const [player1, setPlayer1] = useState<string>("");
  const [player2, setPlayer2] = useState<string>("");
  const [player3, setPlayer3] = useState<string>("");
  const [allPlayers, setAllPlayers] = useState<string[]>([]);
  const [batsmenData, setBatsmenData] = useState<PlayerBatting[]>([]);
  const [bowlersData, setBowlersData] = useState<PlayerBowling[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPlayerData();
  }, []);

  const loadPlayerData = async () => {
    try {
      setLoading(true);
      const responses = await Promise.all([
        fetch("/src/assets/nepal_top_batsmen.csv"),
        fetch("/src/assets/nepal_top_bowlers.csv")
      ]);

      const [batsmenText, bowlersText] = await Promise.all([
        responses[0].text(),
        responses[1].text()
      ]);

      const batsmenWorkbook = XLSX.read(batsmenText, { type: "string" });
      const bowlersWorkbook = XLSX.read(bowlersText, { type: "string" });

      const batsmen: PlayerBatting[] = XLSX.utils.sheet_to_json(
        batsmenWorkbook.Sheets[batsmenWorkbook.SheetNames[0]]
      );

      const bowlers: PlayerBowling[] = XLSX.utils.sheet_to_json(
        bowlersWorkbook.Sheets[bowlersWorkbook.SheetNames[0]]
      );

      setBatsmenData(batsmen);
      setBowlersData(bowlers);

      const uniquePlayers = new Set([
        ...batsmen.map(p => p.Player),
        ...bowlers.map(p => p.Player)
      ]);

      setAllPlayers(Array.from(uniquePlayers).sort());
    } catch (error) {
      console.error("Error loading player data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getPlayerData = (playerName: string) => {
    const batting = batsmenData.find(p => p.Player === playerName);
    const bowling = bowlersData.find(p => p.Player === playerName);
    return { batting, bowling };
  };

  const getComparisonData = () => {
    const players = [player1, player2, player3].filter(Boolean);
    if (players.length < 2) return null;

    const comparison = players.map(playerName => {
      const { batting, bowling } = getPlayerData(playerName);
      
      let runs = 0, wickets = 0, avg = 0, sr = 0, economy = 0;
      
      if (format === "T20I") {
        runs = batting?.["T20I Runs"] || 0;
        wickets = bowling?.["T20I Wickets"] || 0;
      } else if (format === "ODI") {
        runs = batting?.["ODI Runs"] || 0;
        wickets = bowling?.["ODI Wickets"] || 0;
      } else {
        runs = batting?.Runs || 0;
        wickets = bowling?.Wickets || 0;
      }

      avg = batting?.Average || 0;
      sr = batting?.["Strike Rate"] || 0;
      economy = bowling?.Economy || 0;

      return {
        player: playerName,
        runs,
        wickets,
        avg,
        sr,
        economy,
        batting,
        bowling
      };
    });

    return comparison;
  };

  const getRadarData = () => {
    const comparison = getComparisonData();
    if (!comparison) return [];

    const metrics = ["Runs", "Average", "Strike Rate", "Wickets", "Economy"];
    
    return metrics.map(metric => {
      const dataPoint: any = { metric };
      
      comparison.forEach(player => {
        switch (metric) {
          case "Runs":
            dataPoint[player.player] = Math.min(100, (player.runs / 20));
            break;
          case "Average":
            dataPoint[player.player] = Math.min(100, (player.avg * 2));
            break;
          case "Strike Rate":
            dataPoint[player.player] = Math.min(100, player.sr);
            break;
          case "Wickets":
            dataPoint[player.player] = Math.min(100, (player.wickets * 2));
            break;
          case "Economy":
            dataPoint[player.player] = Math.max(0, 100 - (player.economy * 10));
            break;
        }
      });

      return dataPoint;
    });
  };

  const comparison = getComparisonData();
  const radarData = getRadarData();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Activity className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Player Comparison Tool
          </CardTitle>
          <CardDescription>
            Compare batting and bowling statistics across multiple players
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div>
              <label className="text-sm font-medium mb-2 block">Format</label>
              <Select value={format} onValueChange={(value: any) => setFormat(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Overall">Overall</SelectItem>
                  <SelectItem value="T20I">T20I</SelectItem>
                  <SelectItem value="ODI">ODI</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Player 1</label>
              <Select value={player1} onValueChange={setPlayer1}>
                <SelectTrigger>
                  <SelectValue placeholder="Select player" />
                </SelectTrigger>
                <SelectContent>
                  {allPlayers.map(p => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Player 2</label>
              <Select value={player2} onValueChange={setPlayer2}>
                <SelectTrigger>
                  <SelectValue placeholder="Select player" />
                </SelectTrigger>
                <SelectContent>
                  {allPlayers.map(p => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Player 3 (Optional)</label>
              <Select value={player3} onValueChange={setPlayer3}>
                <SelectTrigger>
                  <SelectValue placeholder="Select player" />
                </SelectTrigger>
                <SelectContent>
                  {allPlayers.map(p => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {comparison && comparison.length >= 2 ? (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Batting Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={comparison}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="player" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="runs" fill="hsl(var(--primary))" name="Runs" />
                        <Bar dataKey="avg" fill="hsl(var(--secondary))" name="Average" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Overall Performance Radar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={radarData}>
                        <PolarGrid />
                        <PolarAngleAxis dataKey="metric" />
                        <PolarRadiusAxis angle={90} domain={[0, 100]} />
                        {comparison.map((player, idx) => (
                          <Radar
                            key={player.player}
                            name={player.player}
                            dataKey={player.player}
                            stroke={`hsl(${idx * 120}, 70%, 50%)`}
                            fill={`hsl(${idx * 120}, 70%, 50%)`}
                            fillOpacity={0.3}
                          />
                        ))}
                        <Legend />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Detailed Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Player</TableHead>
                          <TableHead className="text-right">Matches</TableHead>
                          <TableHead className="text-right">Runs</TableHead>
                          <TableHead className="text-right">Average</TableHead>
                          <TableHead className="text-right">Strike Rate</TableHead>
                          <TableHead className="text-right">50s/100s</TableHead>
                          <TableHead className="text-right">Wickets</TableHead>
                          <TableHead className="text-right">Economy</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {comparison.map((player) => (
                          <TableRow key={player.player}>
                            <TableCell className="font-semibold">{player.player}</TableCell>
                            <TableCell className="text-right">
                              {format === "T20I" 
                                ? player.batting?.["T20I Matches"] || player.bowling?.["T20I Matches"] || 0
                                : format === "ODI"
                                ? player.batting?.["ODI Matches"] || player.bowling?.["ODI Matches"] || 0
                                : player.batting?.Matches || player.bowling?.Matches || 0}
                            </TableCell>
                            <TableCell className="text-right">{player.runs}</TableCell>
                            <TableCell className="text-right">{player.avg.toFixed(2)}</TableCell>
                            <TableCell className="text-right">{player.sr.toFixed(2)}</TableCell>
                            <TableCell className="text-right">
                              {player.batting?.["50s"] || 0}/{player.batting?.["100s"] || 0}
                            </TableCell>
                            <TableCell className="text-right">{player.wickets}</TableCell>
                            <TableCell className="text-right">{player.economy.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center p-8 text-muted-foreground">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Select at least 2 players to compare their statistics</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
