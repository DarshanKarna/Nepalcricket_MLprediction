import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MatchData, OppositionStats } from "@/types/cricket";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

interface OppositionAnalysisProps {
  data: MatchData[];
}

const OppositionAnalysis = ({ data }: OppositionAnalysisProps) => {
  // Calculate opposition statistics
  const oppositionStats = data.reduce((acc, match) => {
    const opponent = match.opponent || "Unknown";
    if (!acc[opponent]) {
      acc[opponent] = {
        opponent,
        matches: 0,
        totalRuns: 0,
        totalWickets: 0,
        wins: 0
      };
    }
    
    acc[opponent].matches++;
    acc[opponent].totalRuns += match.nepal_runs || 0;
    acc[opponent].totalWickets += match.nepal_wickets_lost || 0;
    
    if (match.result?.toLowerCase().includes("won")) {
      acc[opponent].wins++;
    }
    
    return acc;
  }, {} as Record<string, { 
    opponent: string; 
    matches: number; 
    totalRuns: number; 
    totalWickets: number; 
    wins: number; 
  }>);

  const statsArray: OppositionStats[] = Object.values(oppositionStats)
    .map(stat => ({
      opponent: stat.opponent,
      matches: stat.matches,
      avgRuns: Number((stat.totalRuns / stat.matches).toFixed(1)),
      avgWickets: Number((stat.totalWickets / stat.matches).toFixed(1)),
      winRate: Number(((stat.wins / stat.matches) * 100).toFixed(1))
    }))
    .sort((a, b) => b.matches - a.matches);

  // Prepare chart data for top opponents
  const chartData = statsArray.slice(0, 10).map(stat => ({
    opponent: stat.opponent.length > 12 ? stat.opponent.substring(0, 12) + "..." : stat.opponent,
    avgRuns: stat.avgRuns,
    winRate: stat.winRate
  }));

  const getPerformanceBadge = (winRate: number) => {
    if (winRate >= 60) return <Badge className="bg-success text-white">Strong</Badge>;
    if (winRate >= 40) return <Badge variant="secondary">Average</Badge>;
    return <Badge variant="destructive">Weak</Badge>;
  };

  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Performance vs Top Opponents</CardTitle>
          <CardDescription>Average runs and win rate comparison</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="opponent"
                angle={-45}
                textAnchor="end"
                height={100}
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              />
              <YAxis 
                yAxisId="left"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "var(--radius)"
                }}
              />
              <Legend />
              <Bar 
                yAxisId="left"
                dataKey="avgRuns" 
                fill="hsl(var(--chart-1))"
                radius={[8, 8, 0, 0]}
                name="Avg Runs"
              />
              <Bar 
                yAxisId="right"
                dataKey="winRate" 
                fill="hsl(var(--chart-2))"
                radius={[8, 8, 0, 0]}
                name="Win Rate %"
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Opposition Statistics</CardTitle>
          <CardDescription>Complete performance breakdown by opponent</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Opposition</TableHead>
                  <TableHead className="text-center">Matches</TableHead>
                  <TableHead className="text-center">Avg Runs</TableHead>
                  <TableHead className="text-center">Avg Wickets</TableHead>
                  <TableHead className="text-center">Win Rate</TableHead>
                  <TableHead className="text-center">Performance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {statsArray.map((stat) => (
                  <TableRow key={stat.opponent}>
                    <TableCell className="font-medium">{stat.opponent}</TableCell>
                    <TableCell className="text-center">{stat.matches}</TableCell>
                    <TableCell className="text-center font-semibold text-primary">
                      {stat.avgRuns}
                    </TableCell>
                    <TableCell className="text-center">{stat.avgWickets}</TableCell>
                    <TableCell className="text-center font-semibold">
                      {stat.winRate}%
                    </TableCell>
                    <TableCell className="text-center">
                      {getPerformanceBadge(stat.winRate)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OppositionAnalysis;
