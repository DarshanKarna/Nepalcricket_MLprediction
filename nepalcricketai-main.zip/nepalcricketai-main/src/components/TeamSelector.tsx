import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp, Activity, Target } from "lucide-react";
import * as XLSX from "xlsx";
import { PlayerBatting, PlayerBowling, PlayerRating } from "@/types/player";

interface TeamSelectorProps {
  format: "T20I" | "ODI";
}

export const TeamSelector = ({ format }: TeamSelectorProps) => {
  const [sortBy, setSortBy] = useState<"combined" | "batting" | "bowling" | "allrounder">("combined");
  const [selectedTeam, setSelectedTeam] = useState<PlayerRating[]>([]);
  const [allPlayers, setAllPlayers] = useState<PlayerRating[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPlayerData();
  }, [format]);

  useEffect(() => {
    if (allPlayers.length > 0) {
      selectBestTeam();
    }
  }, [sortBy, allPlayers]);

  const loadPlayerData = async () => {
    try {
      setLoading(true);
      const batsmenFile = format === "T20I" 
        ? "/src/assets/nepal_t20i_batsmen.csv"
        : "/src/assets/nepal_odi_batsmen.csv";
      const bowlersFile = format === "T20I"
        ? "/src/assets/nepal_t20i_bowlers.csv"
        : "/src/assets/nepal_odi_bowlers.csv";

      const [batsmenResponse, bowlersResponse] = await Promise.all([
        fetch(batsmenFile),
        fetch(bowlersFile)
      ]);

      const [batsmenText, bowlersText] = await Promise.all([
        batsmenResponse.text(),
        bowlersResponse.text()
      ]);

      const batsmenWorkbook = XLSX.read(batsmenText, { type: "string" });
      const bowlersWorkbook = XLSX.read(bowlersText, { type: "string" });

      const batsmenData: PlayerBatting[] = XLSX.utils.sheet_to_json(
        batsmenWorkbook.Sheets[batsmenWorkbook.SheetNames[0]]
      );

      const bowlersData: PlayerBowling[] = XLSX.utils.sheet_to_json(
        bowlersWorkbook.Sheets[bowlersWorkbook.SheetNames[0]]
      );

      const ratings = calculatePlayerRatings(batsmenData, bowlersData, format);
      setAllPlayers(ratings);
    } catch (error) {
      console.error("Error loading player data:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculatePlayerRatings = (
    batsmen: PlayerBatting[],
    bowlers: PlayerBowling[],
    format: "T20I" | "ODI"
  ): PlayerRating[] => {
    const playerMap = new Map<string, PlayerRating>();

    // Calculate batting scores
    batsmen.forEach((bat) => {
      const relevantMatches = format === "T20I" ? bat["T20I Matches"] : bat["ODI Matches"];
      const relevantRuns = format === "T20I" ? bat["T20I Runs"] : bat["ODI Runs"];
      
      if (relevantMatches < 5) return; // Minimum 5 matches

      const battingScore = 
        (relevantRuns / 100) * 0.4 +
        (bat.Average / 10) * 0.3 +
        (bat["Strike Rate"] / 10) * 0.2 +
        (bat["50s"] * 2 + bat["100s"] * 5) * 0.1;

      playerMap.set(bat.Player, {
        player: bat.Player,
        battingScore,
        bowlingScore: 0,
        combinedScore: battingScore,
        role: "Batsman",
        battingStats: bat,
      });
    });

    // Calculate bowling scores and identify all-rounders
    bowlers.forEach((bowl) => {
      const relevantMatches = format === "T20I" ? bowl["T20I Matches"] : bowl["ODI Matches"];
      const relevantWickets = format === "T20I" ? bowl["T20I Wickets"] : bowl["ODI Wickets"];
      
      if (relevantMatches < 5) return; // Minimum 5 matches

      const bowlingScore = 
        (relevantWickets / 10) * 0.4 +
        (Math.max(0, 40 - bowl.Average) / 40) * 0.25 +
        (Math.max(0, 10 - bowl.Economy) / 10) * 0.25 +
        (bowl["4W"] * 2 + bowl["5W"] * 5) * 0.1;

      const existing = playerMap.get(bowl.Player);
      if (existing) {
        // All-rounder
        existing.bowlingScore = bowlingScore;
        existing.combinedScore = existing.battingScore + bowlingScore;
        existing.role = "All-rounder";
        existing.bowlingStats = bowl;
      } else {
        // Pure bowler
        playerMap.set(bowl.Player, {
          player: bowl.Player,
          battingScore: 0,
          bowlingScore,
          combinedScore: bowlingScore,
          role: "Bowler",
          bowlingStats: bowl,
        });
      }
    });

    return Array.from(playerMap.values());
  };

  const selectBestTeam = () => {
    let sorted = [...allPlayers];

    switch (sortBy) {
      case "batting":
        sorted.sort((a, b) => b.battingScore - a.battingScore);
        break;
      case "bowling":
        sorted.sort((a, b) => b.bowlingScore - a.bowlingScore);
        break;
      case "allrounder":
        sorted = sorted.filter(p => p.role === "All-rounder");
        sorted.sort((a, b) => b.combinedScore - a.combinedScore);
        break;
      default:
        sorted.sort((a, b) => b.combinedScore - a.combinedScore);
    }

    // Smart team selection: 5 batsmen, 1 wicketkeeper, 3 all-rounders, 2 bowlers
    const team: PlayerRating[] = [];
    const batsmen = sorted.filter(p => p.role === "Batsman").slice(0, 5);
    const allRounders = sorted.filter(p => p.role === "All-rounder").slice(0, 3);
    const bowlers = sorted.filter(p => p.role === "Bowler").slice(0, 3);

    team.push(...batsmen, ...allRounders, ...bowlers);

    // Fill remaining spots if needed
    while (team.length < 11) {
      const remaining = sorted.find(p => !team.includes(p));
      if (remaining) team.push(remaining);
      else break;
    }

    setSelectedTeam(team.slice(0, 11));
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "Batsman":
        return "bg-blue-500";
      case "Bowler":
        return "bg-green-500";
      case "All-rounder":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Activity className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Best Playing XI for {format}
          </CardTitle>
          <CardDescription>
            AI-powered team selection based on comprehensive performance metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Selection Criteria</label>
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="combined">
                    <div className="flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Combined Performance
                    </div>
                  </SelectItem>
                  <SelectItem value="batting">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Batting Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="bowling">
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      Bowling Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="allrounder">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      All-rounder Focus
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={selectBestTeam} className="mt-6">
              Refresh Team
            </Button>
          </div>

          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead>Player</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="text-right">Bat Score</TableHead>
                  <TableHead className="text-right">Bowl Score</TableHead>
                  <TableHead className="text-right">Total Score</TableHead>
                  <TableHead className="text-right">Key Stats</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedTeam.map((player, idx) => (
                  <TableRow key={player.player}>
                    <TableCell className="font-medium">{idx + 1}</TableCell>
                    <TableCell className="font-semibold">{player.player}</TableCell>
                    <TableCell>
                      <Badge className={getRoleBadgeColor(player.role)}>
                        {player.role}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {player.battingScore.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      {player.bowlingScore.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right font-bold">
                      {player.combinedScore.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right text-sm text-muted-foreground">
                      {player.battingStats && (
                        <span>
                          {format === "T20I" ? player.battingStats["T20I Runs"] : player.battingStats["ODI Runs"]} runs
                          {player.bowlingStats && " • "}
                        </span>
                      )}
                      {player.bowlingStats && (
                        <span>
                          {format === "T20I" ? player.bowlingStats["T20I Wickets"] : player.bowlingStats["ODI Wickets"]} wkts
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="mt-4 p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Selection Algorithm:</strong> Players are rated based on runs, average, strike rate (batting),
              wickets, economy, bowling average (bowling), and match impact. Minimum 5 matches required in the selected format.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
