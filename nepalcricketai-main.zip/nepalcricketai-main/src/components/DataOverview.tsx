import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MatchData } from "@/types/cricket";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface DataOverviewProps {
  data: MatchData[];
}

const DataOverview = ({ data }: DataOverviewProps) => {
  // Prepare runs trend data
  const runsTrend = data.slice(-20).map((match, idx) => ({
    match: idx + 1,
    runs: match.nepal_runs || 0,
    opponent: match.opponent?.substring(0, 10) || "Unknown"
  }));

  // Prepare wickets distribution
  const wicketsDistribution = Array.from({ length: 11 }, (_, i) => {
    const count = data.filter(m => m.nepal_wickets_lost === i).length;
    return { wickets: i.toString(), count };
  });

  // Calculate venue stats
  const venueStats = data.reduce((acc, match) => {
    const venue = match.venue || "Unknown";
    if (!acc[venue]) {
      acc[venue] = { matches: 0, totalRuns: 0, wins: 0 };
    }
    acc[venue].matches++;
    acc[venue].totalRuns += match.nepal_runs || 0;
    if (match.result?.toLowerCase().includes("won")) {
      acc[venue].wins++;
    }
    return acc;
  }, {} as Record<string, { matches: number; totalRuns: number; wins: number }>);

  const topVenues = Object.entries(venueStats)
    .sort((a, b) => b[1].matches - a[1].matches)
    .slice(0, 8)
    .map(([venue, stats]) => ({
      venue: venue.substring(0, 15),
      avgRuns: (stats.totalRuns / stats.matches).toFixed(1),
      matches: stats.matches
    }));

  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Recent Performance Trend</CardTitle>
          <CardDescription>Last 20 matches run scoring pattern</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={runsTrend}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="match" 
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <YAxis 
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "var(--radius)"
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="runs" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={{ fill: "hsl(var(--primary))", r: 4 }}
                name="Runs Scored"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Wickets Distribution</CardTitle>
            <CardDescription>Frequency of wickets lost per match</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={wicketsDistribution}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="wickets"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis 
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)"
                  }}
                />
                <Bar 
                  dataKey="count" 
                  fill="hsl(var(--chart-2))"
                  radius={[8, 8, 0, 0]}
                  name="Matches"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Venues Performance</CardTitle>
            <CardDescription>Average runs by venue (min 1 match)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={topVenues} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  type="number"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis 
                  type="category" 
                  dataKey="venue"
                  width={100}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)"
                  }}
                />
                <Bar 
                  dataKey="avgRuns" 
                  fill="hsl(var(--chart-1))"
                  radius={[0, 8, 8, 0]}
                  name="Avg Runs"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DataOverview;
