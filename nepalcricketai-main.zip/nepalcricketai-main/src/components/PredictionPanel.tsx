import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { MatchData, PredictionResult, WicketPrediction } from "@/types/cricket";
import { Brain, TrendingUp } from "lucide-react";
import * as tf from "@tensorflow/tfjs";
import { useToast } from "@/hooks/use-toast";

interface PredictionPanelProps {
  data: MatchData[];
  format: "T20I" | "ODI" | "Both";
}

const PredictionPanel = ({ data, format }: PredictionPanelProps) => {
  const [selectedOpponent, setSelectedOpponent] = useState<string>("");
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isTraining, setIsTraining] = useState(false);
  const { toast } = useToast();

  const opponents = Array.from(new Set(data.map(m => m.opponent).filter(Boolean))) as string[];

  const trainAndPredict = async () => {
    if (!selectedOpponent) {
      toast({
        title: "Select Opposition",
        description: "Please select an opponent team first",
        variant: "destructive"
      });
      return;
    }

    setIsTraining(true);
    
    try {
      // Filter data for selected opponent
      const opponentData = data.filter(m => m.opponent === selectedOpponent);
      
      if (opponentData.length < 3) {
        toast({
          title: "Insufficient Data",
          description: "Need at least 3 matches against this opponent for prediction",
          variant: "destructive"
        });
        setIsTraining(false);
        return;
      }

      // Prepare training data
      const wicketsData = opponentData.map(m => m.nepal_wickets_lost || 0);
      const runsData = opponentData.map(m => m.nepal_runs || 0);

      // Simple linear regression model
      const model = tf.sequential({
        layers: [
          tf.layers.dense({ units: 16, activation: 'relu', inputShape: [1] }),
          tf.layers.dense({ units: 8, activation: 'relu' }),
          tf.layers.dense({ units: 1 })
        ]
      });

      model.compile({
        optimizer: tf.train.adam(0.01),
        loss: 'meanSquaredError'
      });

      const xs = tf.tensor2d(wicketsData, [wicketsData.length, 1]);
      const ys = tf.tensor2d(runsData, [runsData.length, 1]);

      // Train the model
      await model.fit(xs, ys, {
        epochs: 50,
        verbose: 0
      });

      // Generate predictions for each wicket
      const wicketPredictions: WicketPrediction[] = [];
      for (let wicket = 0; wicket <= 10; wicket++) {
        const input = tf.tensor2d([[wicket]]);
        const pred = model.predict(input) as tf.Tensor;
        const predictedRuns = (await pred.data())[0];
        wicketPredictions.push({
          wicket,
          expectedRuns: Math.max(0, Math.round(predictedRuns))
        });
        input.dispose();
        pred.dispose();
      }

      // Calculate average predicted runs
      const avgPredictedRuns = runsData.reduce((a, b) => a + b, 0) / runsData.length;
      const stdDev = Math.sqrt(
        runsData.reduce((sq, n) => sq + Math.pow(n - avgPredictedRuns, 2), 0) / runsData.length
      );
      const confidence = Math.max(0.5, Math.min(0.95, 1 - (stdDev / avgPredictedRuns)));

      setPrediction({
        predictedRuns: Math.round(avgPredictedRuns),
        confidence: confidence * 100,
        wicketPredictions
      });

      // Cleanup
      xs.dispose();
      ys.dispose();
      model.dispose();

      toast({
        title: "Prediction Complete",
        description: `Model trained on ${opponentData.length} matches`,
      });

    } catch (error) {
      console.error("Prediction error:", error);
      toast({
        title: "Prediction Failed",
        description: "An error occurred during prediction",
        variant: "destructive"
      });
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            ML-Based Run Prediction ({format})
          </CardTitle>
          <CardDescription>
            Neural network model predicting runs based on wickets and historical performance for {format} format{format === "Both" ? "s" : ""}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Select Opposition</Label>
            <Select value={selectedOpponent} onValueChange={setSelectedOpponent}>
              <SelectTrigger>
                <SelectValue placeholder="Choose opponent team" />
              </SelectTrigger>
              <SelectContent>
                {opponents.map(opp => (
                  <SelectItem key={opp} value={opp}>{opp}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button 
            onClick={trainAndPredict}
            disabled={isTraining || !selectedOpponent}
            className="w-full"
          >
            {isTraining ? "Training Model..." : "Generate Prediction"}
          </Button>
        </CardContent>
      </Card>

      {prediction && (
        <>
          <Card className="border-primary">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-success" />
                Prediction Results
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Expected Total Runs</p>
                  <p className="text-4xl font-bold text-primary">{prediction.predictedRuns}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Model Confidence</p>
                  <p className="text-4xl font-bold text-success">{prediction.confidence.toFixed(1)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Wicket-wise Run Prediction</CardTitle>
              <CardDescription>Expected runs when specific wickets fall</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {prediction.wicketPredictions.map(wp => (
                  <div 
                    key={wp.wicket}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                  >
                    <span className="font-medium text-foreground">
                      After {wp.wicket} wicket{wp.wicket !== 1 ? 's' : ''}
                    </span>
                    <span className="text-lg font-bold text-primary">
                      ~{wp.expectedRuns} runs
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default PredictionPanel;
