export interface PlayerBatting {
  Player: string;
  Matches: number;
  Innings: number;
  "Not Outs": number;
  Runs: number;
  "Highest Score": string;
  Average: number;
  "Strike Rate": number;
  "Balls Faced": number;
  "100s": number;
  "50s": number;
  Fours: number;
  Sixes: number;
  "T20I Matches": number;
  "T20I Runs": number;
  "ODI Matches": number;
  "ODI Runs": number;
}

export interface PlayerBowling {
  Player: string;
  Matches: number;
  Innings: number;
  Balls: number;
  Runs: number;
  Wickets: number;
  "Best Bowling": string;
  Average: number;
  Economy: number;
  "Strike Rate": number;
  Maidens: number;
  "4W": number;
  "5W": number;
  "T20I Matches": number;
  "T20I Wickets": number;
  "ODI Matches": number;
  "ODI Wickets": number;
}

export interface PlayerRating {
  player: string;
  battingScore: number;
  bowlingScore: number;
  combinedScore: number;
  role: "Batsman" | "Bowler" | "All-rounder";
  battingStats?: PlayerBatting;
  bowlingStats?: PlayerBowling;
}
