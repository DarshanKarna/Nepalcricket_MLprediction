export interface MatchData {
  date?: string;
  opponent?: string;
  venue?: string;
  result?: string;
  nepal_runs?: number;
  nepal_wickets_lost?: number;
  opponent_runs?: number;
  opponent_wickets_lost?: number;
}

export interface PredictionResult {
  predictedRuns: number;
  confidence: number;
  wicketPredictions: WicketPrediction[];
}

export interface WicketPrediction {
  wicket: number;
  expectedRuns: number;
}

export interface OppositionStats {
  opponent: string;
  matches: number;
  avgRuns: number;
  avgWickets: number;
  winRate: number;
}
