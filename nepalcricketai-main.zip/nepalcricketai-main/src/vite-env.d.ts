/// <reference types="vite/client" />

declare module "*.xlsx" {
  const src: string;
  export default src;
}

declare module "*.csv" {
  const src: string;
  export default src;
}
