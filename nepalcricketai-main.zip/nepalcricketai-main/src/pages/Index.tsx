import { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trophy, Target, TrendingUp, Activity } from "lucide-react";
import t20iMatchDataFile from "@/assets/nepal_t20i_matches.xlsx";
import odiMatchDataFile from "@/assets/nepal_odi_matches.csv";
import DataOverview from "@/components/DataOverview";
import PredictionPanel from "@/components/PredictionPanel";
import OppositionAnalysis from "@/components/OppositionAnalysis";
import { TeamSelector } from "@/components/TeamSelector";
import { PlayerComparison } from "@/components/PlayerComparison";
import { MatchData } from "@/types/cricket";

const Index = () => {
  const [t20iData, setT20iData] = useState<MatchData[]>([]);
  const [odiData, setOdiData] = useState<MatchData[]>([]);
  const [selectedFormat, setSelectedFormat] = useState<"T20I" | "ODI" | "Both">("Both");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load T20I data from Excel
      const t20Response = await fetch(t20iMatchDataFile);
      const t20ArrayBuffer = await t20Response.arrayBuffer();
      const t20Workbook = XLSX.read(t20ArrayBuffer, { type: "array" });
      const t20SheetName = t20Workbook.SheetNames[0];
      const t20Worksheet = t20Workbook.Sheets[t20SheetName];
      const t20JsonData = XLSX.utils.sheet_to_json<MatchData>(t20Worksheet);
      setT20iData(t20JsonData);

      // Load ODI data from CSV
      const odiResponse = await fetch(odiMatchDataFile);
      const odiText = await odiResponse.text();
      Papa.parse(odiText, {
        header: true,
        complete: (results) => {
          setOdiData(results.data as MatchData[]);
        }
      });
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const matchData = selectedFormat === "T20I" ? t20iData : 
                    selectedFormat === "ODI" ? odiData : 
                    [...t20iData, ...odiData];

  // Filter out invalid data
  const validMatches = matchData.filter(m => 
    m.result && 
    typeof m.nepal_runs === 'number' && 
    !isNaN(m.nepal_runs)
  );

  const totalMatches = validMatches.length;
  const wins = validMatches.filter(m => m.result?.toLowerCase().includes("won")).length;
  
  // Calculate averages with proper null checking
  const totalRuns = validMatches.reduce((acc, m) => acc + (m.nepal_runs || 0), 0);
  const avgRuns = totalMatches > 0 ? totalRuns / totalMatches : 0;
  
  const totalWickets = validMatches.reduce((acc, m) => acc + (m.nepal_wickets_lost || 0), 0);
  const avgWickets = totalMatches > 0 ? totalWickets / totalMatches : 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Activity className="w-16 h-16 animate-spin text-primary mx-auto mb-4" />
          <p className="text-lg text-muted-foreground">Loading cricket data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-gradient-to-r from-card to-card/80 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-xl">
                <Trophy className="w-10 h-10 text-primary" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-foreground bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Nepal Cricket Analytics
                </h1>
                <p className="text-muted-foreground mt-1">AI-Powered Performance Prediction & Team Selection System</p>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-muted/50 px-4 py-2 rounded-lg">
              <span className="text-sm font-medium text-muted-foreground">Format:</span>
              <Select value={selectedFormat} onValueChange={(value: "T20I" | "ODI" | "Both") => setSelectedFormat(value)}>
                <SelectTrigger className="w-32 border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Both">Both</SelectItem>
                  <SelectItem value="T20I">T20I</SelectItem>
                  <SelectItem value="ODI">ODI</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-border bg-gradient-to-br from-card to-card/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Matches</CardTitle>
              <div className="p-2 bg-primary/10 rounded-lg">
                <Trophy className="h-5 w-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalMatches}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {selectedFormat === "Both" ? "All formats" : selectedFormat} analyzed
              </p>
            </CardContent>
          </Card>

          <Card className="border-border bg-gradient-to-br from-card to-card/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
              <div className="p-2 bg-success/10 rounded-lg">
                <Target className="h-5 w-5 text-success" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-success">
                {totalMatches > 0 ? ((wins / totalMatches) * 100).toFixed(1) : 0}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {wins} wins out of {totalMatches}
              </p>
            </CardContent>
          </Card>

          <Card className="border-border bg-gradient-to-br from-card to-card/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Runs</CardTitle>
              <div className="p-2 bg-info/10 rounded-lg">
                <TrendingUp className="h-5 w-5 text-info" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-info">{avgRuns.toFixed(1)}</div>
              <p className="text-xs text-muted-foreground mt-1">Per innings scored</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-gradient-to-br from-card to-card/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Wickets</CardTitle>
              <div className="p-2 bg-warning/10 rounded-lg">
                <Activity className="h-5 w-5 text-warning" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-warning">{avgWickets.toFixed(1)}</div>
              <p className="text-xs text-muted-foreground mt-1">Per innings lost</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
            <TabsTrigger value="overview">Data Overview</TabsTrigger>
            <TabsTrigger value="predictions">ML Predictions</TabsTrigger>
            <TabsTrigger value="opposition">Opposition Analysis</TabsTrigger>
            <TabsTrigger value="team-t20i">Best XI T20I</TabsTrigger>
            <TabsTrigger value="team-odi">Best XI ODI</TabsTrigger>
            <TabsTrigger value="comparison">Player Compare</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <DataOverview data={validMatches} />
          </TabsContent>

          <TabsContent value="predictions" className="space-y-4">
            <PredictionPanel data={validMatches} format={selectedFormat} />
          </TabsContent>

          <TabsContent value="opposition" className="space-y-4">
            <OppositionAnalysis data={validMatches} />
          </TabsContent>

          <TabsContent value="team-t20i" className="space-y-4">
            <TeamSelector format="T20I" />
          </TabsContent>

          <TabsContent value="team-odi" className="space-y-4">
            <TeamSelector format="ODI" />
          </TabsContent>

          <TabsContent value="comparison" className="space-y-4">
            <PlayerComparison />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;
